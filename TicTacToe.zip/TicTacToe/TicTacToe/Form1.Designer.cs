﻿namespace TicTacToe
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            btnTic9 = new Button();
            btnTic6 = new Button();
            btnTic3 = new Button();
            btnTic8 = new Button();
            btnTic7 = new Button();
            btnTic5 = new Button();
            btnTic4 = new Button();
            btnTic2 = new Button();
            btnTic1 = new Button();
            panel2 = new Panel();
            panel3 = new Panel();
            panel5 = new Panel();
            label3 = new Label();
            label2 = new Label();
            PLAY_O = new Label();
            PLAY_X = new Label();
            panel4 = new Panel();
            btnNewGame = new Button();
            btnExit = new Button();
            btnReset = new Button();
            label1 = new Label();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            panel3.SuspendLayout();
            panel5.SuspendLayout();
            panel4.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BorderStyle = BorderStyle.Fixed3D;
            panel1.Controls.Add(btnTic9);
            panel1.Controls.Add(btnTic6);
            panel1.Controls.Add(btnTic3);
            panel1.Controls.Add(btnTic8);
            panel1.Controls.Add(btnTic7);
            panel1.Controls.Add(btnTic5);
            panel1.Controls.Add(btnTic4);
            panel1.Controls.Add(btnTic2);
            panel1.Controls.Add(btnTic1);
            panel1.Location = new Point(17, 16);
            panel1.Name = "panel1";
            panel1.Size = new Size(782, 567);
            panel1.TabIndex = 0;
            // 
            // btnTic9
            // 
            btnTic9.BackColor = Color.FromArgb(224, 224, 224);
            btnTic9.Font = new Font("Algerian", 72F, FontStyle.Bold);
            btnTic9.ForeColor = Color.FromArgb(192, 0, 0);
            btnTic9.Location = new Point(491, 364);
            btnTic9.Name = "btnTic9";
            btnTic9.Size = new Size(220, 170);
            btnTic9.TabIndex = 0;
            btnTic9.UseVisualStyleBackColor = false;
            btnTic9.Click += btnTic9_Click;
            // 
            // btnTic6
            // 
            btnTic6.BackColor = Color.FromArgb(224, 224, 224);
            btnTic6.Font = new Font("Algerian", 72F, FontStyle.Bold);
            btnTic6.ForeColor = Color.FromArgb(192, 0, 0);
            btnTic6.Location = new Point(491, 188);
            btnTic6.Name = "btnTic6";
            btnTic6.Size = new Size(220, 170);
            btnTic6.TabIndex = 0;
            btnTic6.UseVisualStyleBackColor = false;
            btnTic6.Click += btnTic6_Click;
            // 
            // btnTic3
            // 
            btnTic3.BackColor = Color.FromArgb(224, 224, 224);
            btnTic3.Font = new Font("Algerian", 72F, FontStyle.Bold);
            btnTic3.ForeColor = Color.FromArgb(192, 0, 0);
            btnTic3.Location = new Point(491, 12);
            btnTic3.Name = "btnTic3";
            btnTic3.Size = new Size(220, 170);
            btnTic3.TabIndex = 0;
            btnTic3.UseVisualStyleBackColor = false;
            btnTic3.Click += btnTic3_Click;
            // 
            // btnTic8
            // 
            btnTic8.BackColor = Color.FromArgb(224, 224, 224);
            btnTic8.Font = new Font("Algerian", 72F, FontStyle.Bold);
            btnTic8.ForeColor = Color.FromArgb(192, 0, 0);
            btnTic8.Location = new Point(250, 364);
            btnTic8.Name = "btnTic8";
            btnTic8.Size = new Size(220, 170);
            btnTic8.TabIndex = 0;
            btnTic8.UseVisualStyleBackColor = false;
            btnTic8.Click += btnTic8_Click;
            // 
            // btnTic7
            // 
            btnTic7.BackColor = Color.FromArgb(224, 224, 224);
            btnTic7.Font = new Font("Algerian", 72F, FontStyle.Bold);
            btnTic7.ForeColor = Color.FromArgb(192, 0, 0);
            btnTic7.Location = new Point(13, 364);
            btnTic7.Name = "btnTic7";
            btnTic7.Size = new Size(220, 170);
            btnTic7.TabIndex = 0;
            btnTic7.UseVisualStyleBackColor = false;
            btnTic7.Click += btnTic7_Click;
            // 
            // btnTic5
            // 
            btnTic5.BackColor = Color.FromArgb(224, 224, 224);
            btnTic5.Font = new Font("Algerian", 72F, FontStyle.Bold);
            btnTic5.ForeColor = Color.FromArgb(192, 0, 0);
            btnTic5.Location = new Point(250, 188);
            btnTic5.Name = "btnTic5";
            btnTic5.Size = new Size(220, 170);
            btnTic5.TabIndex = 0;
            btnTic5.UseVisualStyleBackColor = false;
            btnTic5.Click += btnTic5_Click;
            // 
            // btnTic4
            // 
            btnTic4.BackColor = Color.FromArgb(224, 224, 224);
            btnTic4.Font = new Font("Algerian", 72F, FontStyle.Bold);
            btnTic4.ForeColor = Color.FromArgb(192, 0, 0);
            btnTic4.Location = new Point(13, 188);
            btnTic4.Name = "btnTic4";
            btnTic4.Size = new Size(220, 170);
            btnTic4.TabIndex = 0;
            btnTic4.UseVisualStyleBackColor = false;
            btnTic4.Click += btnTic4_Click;
            // 
            // btnTic2
            // 
            btnTic2.BackColor = Color.FromArgb(224, 224, 224);
            btnTic2.Font = new Font("Algerian", 72F, FontStyle.Bold);
            btnTic2.ForeColor = Color.FromArgb(192, 0, 0);
            btnTic2.Location = new Point(250, 12);
            btnTic2.Name = "btnTic2";
            btnTic2.Size = new Size(220, 170);
            btnTic2.TabIndex = 0;
            btnTic2.UseVisualStyleBackColor = false;
            btnTic2.Click += btnTic2_Click;
            // 
            // btnTic1
            // 
            btnTic1.BackColor = Color.Gainsboro;
            btnTic1.Font = new Font("Algerian", 72F, FontStyle.Bold);
            btnTic1.ForeColor = Color.FromArgb(192, 0, 0);
            btnTic1.Location = new Point(13, 12);
            btnTic1.Name = "btnTic1";
            btnTic1.Size = new Size(220, 170);
            btnTic1.TabIndex = 0;
            btnTic1.UseVisualStyleBackColor = false;
            btnTic1.Click += btnTic1_Click;
            // 
            // panel2
            // 
            panel2.BorderStyle = BorderStyle.Fixed3D;
            panel2.Controls.Add(panel3);
            panel2.Controls.Add(panel1);
            panel2.Location = new Point(12, 122);
            panel2.Name = "panel2";
            panel2.Size = new Size(1344, 607);
            panel2.TabIndex = 0;
            // 
            // panel3
            // 
            panel3.BorderStyle = BorderStyle.Fixed3D;
            panel3.Controls.Add(panel5);
            panel3.Controls.Add(panel4);
            panel3.Location = new Point(818, 16);
            panel3.Name = "panel3";
            panel3.Size = new Size(503, 567);
            panel3.TabIndex = 0;
            // 
            // panel5
            // 
            panel5.BorderStyle = BorderStyle.Fixed3D;
            panel5.Controls.Add(label3);
            panel5.Controls.Add(label2);
            panel5.Controls.Add(PLAY_O);
            panel5.Controls.Add(PLAY_X);
            panel5.Location = new Point(17, 304);
            panel5.Name = "panel5";
            panel5.Size = new Size(463, 230);
            panel5.TabIndex = 0;
            // 
            // label3
            // 
            label3.Font = new Font("Segoe UI", 25.8000011F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.WhiteSmoke;
            label3.Location = new Point(-2, 131);
            label3.Name = "label3";
            label3.Size = new Size(222, 61);
            label3.TabIndex = 4;
            label3.Text = "0";
            label3.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            label2.Font = new Font("Segoe UI", 25.8000011F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.WhiteSmoke;
            label2.Location = new Point(234, 23);
            label2.Name = "label2";
            label2.Size = new Size(222, 61);
            label2.TabIndex = 2;
            label2.Text = "0";
            label2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // PLAY_O
            // 
            PLAY_O.BackColor = Color.Gray;
            PLAY_O.BorderStyle = BorderStyle.Fixed3D;
            PLAY_O.Font = new Font("Broadway", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            PLAY_O.ForeColor = Color.MistyRose;
            PLAY_O.Location = new Point(224, 131);
            PLAY_O.Name = "PLAY_O";
            PLAY_O.Size = new Size(225, 62);
            PLAY_O.TabIndex = 2;
            PLAY_O.Text = "PLAYER O";
            PLAY_O.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // PLAY_X
            // 
            PLAY_X.BackColor = Color.Gray;
            PLAY_X.BorderStyle = BorderStyle.Fixed3D;
            PLAY_X.Font = new Font("Broadway", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            PLAY_X.ForeColor = Color.MistyRose;
            PLAY_X.Location = new Point(3, 24);
            PLAY_X.Name = "PLAY_X";
            PLAY_X.Size = new Size(220, 62);
            PLAY_X.TabIndex = 3;
            PLAY_X.Text = "PLAYER X:";
            PLAY_X.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panel4
            // 
            panel4.BorderStyle = BorderStyle.Fixed3D;
            panel4.Controls.Add(btnNewGame);
            panel4.Controls.Add(btnExit);
            panel4.Controls.Add(btnReset);
            panel4.Location = new Point(17, 24);
            panel4.Name = "panel4";
            panel4.Size = new Size(463, 252);
            panel4.TabIndex = 0;
            // 
            // btnNewGame
            // 
            btnNewGame.BackColor = Color.FromArgb(224, 224, 224);
            btnNewGame.Font = new Font("Ravie", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnNewGame.ForeColor = Color.FromArgb(192, 0, 0);
            btnNewGame.Location = new Point(3, 23);
            btnNewGame.Name = "btnNewGame";
            btnNewGame.Size = new Size(446, 98);
            btnNewGame.TabIndex = 0;
            btnNewGame.Text = "Start New Game";
            btnNewGame.UseVisualStyleBackColor = false;
            btnNewGame.Click += btnNewGame_Click;
            // 
            // btnExit
            // 
            btnExit.BackColor = Color.FromArgb(224, 224, 224);
            btnExit.Font = new Font("Ravie", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnExit.ForeColor = Color.FromArgb(192, 0, 0);
            btnExit.Location = new Point(224, 127);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(195, 98);
            btnExit.TabIndex = 0;
            btnExit.Text = "Exit Game";
            btnExit.TextAlign = ContentAlignment.MiddleLeft;
            btnExit.UseVisualStyleBackColor = false;
            btnExit.Click += btnExit_Click;
            // 
            // btnReset
            // 
            btnReset.BackColor = Color.FromArgb(224, 224, 224);
            btnReset.Font = new Font("Ravie", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnReset.ForeColor = Color.FromArgb(192, 0, 0);
            btnReset.Location = new Point(18, 127);
            btnReset.Name = "btnReset";
            btnReset.Size = new Size(205, 98);
            btnReset.TabIndex = 0;
            btnReset.Text = "Reset Game";
            btnReset.TextAlign = ContentAlignment.MiddleLeft;
            btnReset.UseVisualStyleBackColor = false;
            btnReset.Click += btnReset_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Showcard Gothic", 36F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Sienna;
            label1.Location = new Point(438, 22);
            label1.Name = "label1";
            label1.Size = new Size(557, 74);
            label1.TabIndex = 1;
            label1.Text = "Tic Tac Toe Game";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 192, 192);
            ClientSize = new Size(1368, 741);
            Controls.Add(label1);
            Controls.Add(panel2);
            Name = "Form1";
            Text = "Tic  Tac Toe ";
            Load += Form1_Load;
            panel1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel3.ResumeLayout(false);
            panel5.ResumeLayout(false);
            panel4.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Panel panel2;
        private Button btnTic1;
        private Panel panel3;
        private Panel panel4;
        private Label label1;
        private Button btnTic9;
        private Button btnTic6;
        private Button btnTic3;
        private Button btnTic8;
        private Button btnTic7;
        private Button btnTic5;
        private Button btnTic4;
        private Button btnTic2;
        private Panel panel5;
        private Button btnNewGame;
        private Button btnExit;
        private Button btnReset;
        private Label PLAY_O;
        private Label PLAY_X;
        private Label label3;
        private Label label2;
    }
}
